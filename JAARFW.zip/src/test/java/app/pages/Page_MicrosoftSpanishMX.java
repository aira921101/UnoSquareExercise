package app.pages;

import java.util.Random;

/**
 * @author Angel Avila
 */

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import app.common.JavaScriptFunctions;
import app.common.SeleniumActions;
import app.common.SupportValidations;
import app.common.Constants;
import app.common.ExplicitWaitFunctions;

public class Page_MicrosoftSpanishMX {

	WebDriver driver;

	private SeleniumActions selact;
	private ExplicitWaitFunctions ewaits;
	private JavaScriptFunctions jsf;
	private SupportValidations sva;

	private static final Logger log = LogManager.getLogger(Page_MicrosoftSpanishMX.class.getName());

	public Page_MicrosoftSpanishMX(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		ewaits = new ExplicitWaitFunctions(driver);
		selact = new SeleniumActions(driver);
		jsf = new JavaScriptFunctions(driver);
		sva = new SupportValidations(driver);
	}

	/**
	 * xPath nomenclature:
	 * 
	 * lbl : Label 
	 * txt : TextBox
	 * tar : text area
	 * btn : Button
	 * ck  : CheckBox
	 * rb  : RadioButton
	 * tbl : Table
	 * img : image
	 */

	/*Elements present in Microsoft Page*/
	@FindBy(xpath = "//a[@id='uhfLogo']")
	private WebElement microsoftLogo;

	@FindBy(xpath = "//nav[@id='uhf-g-nav']//li[contains(.,'Windows')]")
	private WebElement windowsTab;

	@FindBy(xpath = "//button[@id='search']")
	private WebElement btnSearch;

	@FindBy(xpath = "//a[normalize-space()='Logout']")
	private WebElement btnLogout;

	@FindBy(xpath  = "//input[@id='cli_shellHeaderSearchInput']")
	private WebElement txtSearchBox;

	//Search Results
	@FindBy(xpath = "//a[@name='tab' and contains(.,'Comprar')]")
	private WebElement btnComprar;
	
	//Categories Menu
	@FindBy(xpath = "//a[@aria-label='Refine by Aplicaciones']")
	private WebElement btnAplicaciones;
	
	@FindBy(xpath = "//*[@id='coreui-productplacementlist-1g76zxk']/div[3]/p[1]")
	private WebElement resultsApplicaciones;
	
	//-----------------------------------------------------------------------------

	/**
	 * Validate once the Brand logo image is present
	 */
	public void validatePageBrandLogo() {
		Assert.assertTrue(ewaits.waitForPageToLoad(35));
		sva.verifyElementExists(microsoftLogo, Constants.EXPLICIT_WAIT_HOMEPAGE);
		log.info("Microsoft Logo image is displayed");
	}

	/**
	 * Go to Windows
	 */
	public void goToWindows() {
		sva.verifyElementExists(windowsTab, Constants.EXPLICIT_WAIT_HOMEPAGE);
		selact.clickOnElement(windowsTab);
		log.info("Page title is displayed.");
	}
	
	/**
	 * Click Search Icon
	 */
	public void clickSearchIcon() {
		sva.verifyElementExists(btnSearch, Constants.EXPLICIT_WAIT_HOMEPAGE);
		selact.clickOnElement(btnSearch);
		log.info("Page title is displayed.");
	}
	
	/**
	 * Send text to search
	 */
	public void sendTextToSearch(String keywordsearch) {
		sva.verifyElementExists(txtSearchBox, Constants.EXPLICIT_WAIT_HOMEPAGE);
		selact.sendTextToElementAndEnterKey(txtSearchBox, keywordsearch);
		log.info("Entered the: "+keywordsearch+" in the searchbox and Enter key pressed!");
	}
	
	/**
	 * Validate Aplicaciones number
	 */
	public void validateAplicacionesLabel () {
		try {
		sva.verifyElementExists(btnComprar, Constants.EXPLICIT_WAIT_HOMEPAGE);
		selact.clickOnElement(btnComprar);
		Thread.sleep(1000);
		sva.verifyElementExists(btnAplicaciones, Constants.EXPLICIT_WAIT_HOMEPAGE);
		selact.clickOnElement(btnAplicaciones);
		sva.verifyElementExists(resultsApplicaciones, Constants.EXPLICIT_WAIT_HOMEPAGE);
		sva.verifyElementContains(resultsApplicaciones, "Se muestran 1 - 90 de 717 resultados", Constants.EXPLICIT_WAIT_HOMEPAGE);
		log.info(resultsApplicaciones.getText());
		}catch (Exception e) {
			//test.log(Status.ERROR, e.getMessage());
			log.error(e.getMessage());
		}
	}
	
	
}
