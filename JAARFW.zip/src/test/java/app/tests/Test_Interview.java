package app.tests;

/***
 * @author Angel Avila.
 */

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.MediaEntityModelProvider;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import app.common.ConfigReader;
import app.common.DriverSetUp;
import app.common.WebSiteFunctions;
import app.pages.Page_MicrosoftSpanishMX;


public class Test_Interview {

	WebDriver driver;

	DriverSetUp ds;
	WebSiteFunctions wsf;
	ConfigReader config;

	ExtentTest test;
	ExtentHtmlReporter htmlReporter;
	ExtentReports report;

	Page_MicrosoftSpanishMX microsoftpage;
	//BSN_SpinUp_HomePage homePage;

	String env;

	private static final Logger log = LogManager.getLogger(Test_Interview.class.getName());

	private DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy.MM.dd.HH.mm");
	private DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy.MM.dd");
	private LocalDateTime now = LocalDateTime.now();

	@BeforeTest
	public void beforeTest() {
		File dailyDir = new File("./Reports/"+dtf1.format(now).toString());
		dailyDir.mkdir();

		report = new ExtentReports();
		htmlReporter = new ExtentHtmlReporter("./Reports/"+dailyDir.getName()+"/Report_"+ Test_Interview.class.getName() + dtf.format(now).toString() + "_Suite.html");
		htmlReporter.loadXMLConfig("extent-config.xml");
		report.attachReporter(htmlReporter);

	}

	@BeforeMethod(description= "Init Test Cases")
	@Parameters({ "browser", "environment", "runType" })
	public void setClasses(String browser, String environment,  String runType) {
		this.env = environment;
		ThreadContext.put("contextKey",this.getClass().getName());
		log.info("The Test Suite " + Test_Interview.class.getName() + " has started");

		//Initialize the driver for the browser.
		ds = new DriverSetUp(browser);

		if (runType.equals("local")) { 
			driver = ds.driveReturn();
			log.info("Local Driver for local execution");
		}

		log.info("Driver initialized: " + driver);

		microsoftpage = new Page_MicrosoftSpanishMX(driver);
		driver.get(config.getQAURL());
		
	}
	

	@Test(description= "TC01 - Search Validation")
	private void TC01_Check_login_valid_data_StepRunner() throws Throwable {
		test = report.createTest("TC01 - Search Validation");

		/**Step 1
		 * Go to Windows
		 */
		log.info("\n ----------------------------------------------------------------------");
		log.info(" ----------- Step 1 Go To Windows");
		test.log(Status.INFO, "Step 1 Go To Windows");
		microsoftpage.goToWindows();
		log.info("Windows Tab is selected");
		test.pass("Windows Tab is selected");
		
		
		/**Step 2
		 * Go to Search
		 */
		log.info("\n ----------------------------------------------------------------------");
		log.info(" ----------- Step 2 Clicking Search Icon");
		test.log(Status.INFO, "Step 2 Clicking Search Icon");	
		microsoftpage.clickSearchIcon();
		log.info("Search Icon clicked");
		test.pass("Search Icon clicked");

		/**Step 3
		 *  Search for �Xbox�
		 * 
		 * Expected: Xbox keyword is entered
		 */
		log.info("\n ----------------------------------------------------------------------");
		log.info(" ----------- Step 3 Searching for " + config.getSearchKeywords().get(0));
		test.log(Status.INFO, "Step 3 Verify the " + config.getSearchKeywords().get(0));
		microsoftpage.sendTextToSearch(config.getSearchKeywords().get(0));
		log.info("Text entered in search field");
		test.info("Text entered in search field.");
		test.pass("Text entered in search field successfully.");


		/**Once in the result page you will see Aplicaciones (647)
		 */
		log.info("\n ----------------------------------------------------------------------");
		log.info(" ----------- Step 4 Validate Aplicaciones 717");
		test.log(Status.INFO, "Step 4 Validate Aplicaciones 717");
		microsoftpage.validateAplicacionesLabel();
		log.info("Validation passed");
		test.pass("Aplicaciones label validated");
		

		log.info("-----------TC01 completed------------");
	}


	
	
	@AfterMethod
	public void afterMethod(ITestResult result) {
		try {
			if (result.getStatus() == ITestResult.SUCCESS) {
				log.info("======PASSED=====");
				test.log(Status.PASS, "The Test Case " + result.getName() + " is PASS");
			} else if (result.getStatus() == ITestResult.FAILURE) {
				log.info("======FAILED=====");
				String method = result.getName();
				StringWriter sw = new StringWriter();
				result.getThrowable().printStackTrace(new PrintWriter(sw));
				String exStackTrace = sw.toString(); 
				log.info("Exception: " + exStackTrace);
			
				test.info(result.getThrowable().getMessage());
				 

				log.info(result.getThrowable().getMessage());

				throw new Exception();
			} else if (result.getStatus() == ITestResult.SKIP) {
				log.info("======SKIPPED=====");
				test.log(Status.SKIP, "The Test Case " + result.getName() + " is SKIP");
				StringWriter sw = new StringWriter();
				result.getThrowable().printStackTrace(new PrintWriter(sw));
				String exStackTrace = sw.toString();
				log.info("Exception: " + exStackTrace);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		log.info("----------------------------------------------------------------------");
		log.info(" -------------- The Test " + result.getName() + " has been completed");
		log.info("----------------------------------------------------------------------");
		report.flush();	
		driver.quit();
	}
}
