package app.common;

/***
 * @author Angel Avila
 */

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;


public class SeleniumActions {
	WebDriver driver;
	Actions actions;
	ExplicitWaitFunctions exwait;
	JavaScriptFunctions jsf;
	private static final Logger log = LogManager.getLogger(SeleniumActions.class.getName());

	public SeleniumActions(WebDriver driver) {
		this.driver = driver;
		exwait = new ExplicitWaitFunctions(driver);
		jsf = new JavaScriptFunctions(driver);
	    actions = new Actions(driver);
	}
	
	/**
	 * This Method returns the trimmed text from a WebElement
	 * 
	 * @param webEl
	 * @return string
	 */
	public String getElementText(WebElement webEl) {
		String text = webEl.getText().trim();
		log.info("The text of the WebElement: "+ webEl +" is : "+text);
		return text;
	}
	
	/**
	 * This Method returns the trimmed text from a WebElement
	 * 
	 * @param webEl
	 * @return string
	 */
	public String getElementText(WebElement webEl, int timeout) {
		Assert.assertTrue(
				exwait.waitForVisibilityOfElement(webEl, Constants.EXPLICIT_WAIT_HOMEPAGE));
		jsf.shadeElem(webEl);
		String text = webEl.getText().trim();
		log.info("The text of the WebElement: "+ webEl +" is : "+text);
		return text;
	}

	/**
	 * 
	 * This Method clicks on a WebElement
	 * 
	 * @param webEl
	 */
	public void clickOnElement(WebElement webEl) {
		Assert.assertTrue(exwait.javaScriptWaitWholePageToLoad(Constants.EXPLICIT_WAIT_HOMEPAGE));
		Assert.assertTrue(exwait.waitForElementToBeClickable(webEl, Constants.EXPLICIT_WAIT_HOMEPAGE));
		String webElName = webEl.toString();
		webEl.click();
		log.info("The Click on a WebElement: "+ webElName );
	}

	public void clickOnElementFromList(List<WebElement> webEl, String elementText) {
		for (WebElement elem : webEl) {
			String elemText = this.getElementText(elem);
			if(elementText.equalsIgnoreCase(elemText)) {
				jsf.shadeElem(elem);
				this.clickOnElement(elem);
				break;
			}
		}
	}
	
	/**
	 * 
	 * This Method Send a String to a WebElement
	 * 
	 * @param webEl
	 * @param text
	 */
	public void sendTextToElement(WebElement webEl, String text) {
		webEl.clear();
		webEl.sendKeys(text);
		log.info("Send the text to the WebElement: "+ webEl  );		
	}
	
	/**
	 * 
	 * This Method Send a String to a WebElement
	 * 
	 * @param webElement
	 * @param text
	 */
	public void sendTextToElementAndEnterKey(WebElement webElement, String text) {
		webElement.click();
		webElement.clear();
		webElement.sendKeys(text + Keys.ENTER);
		//webElement.sendKeys(Keys.ENTER);
		log.info("Send the text to the WebElement: "+ webElement  );		
	}
	
	public String getCurrentURL() {
		String currentURL=driver.getCurrentUrl();
		log.info("The Current URL is : " + currentURL);
		return currentURL;
	}
	
}
