package app.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 
 * This class reads the values from the file configuration.properties
 * 
 * @return Value from configuration.properties
 */
public class JSONDataReader {
	private String env;
	private final Logger log = LogManager.getLogger(JSONDataReader.class.getName());
	Properties pro;

	public JSONDataReader(String env) {
		this.env = env;

		try {

			if(env.equalsIgnoreCase("Prod")) {
				File src = new File("./configurationprod.properties");
				log.info("The environment is: "+ env);
				FileInputStream fis = new FileInputStream(src);

				pro = new Properties();

				pro.load(fis);
			} else if(env.equalsIgnoreCase("Test")) {
				File src = new File("./configuration.properties");
				log.info("The environment is: "+ env);
				FileInputStream fis = new FileInputStream(src);

				pro = new Properties();

				pro.load(fis);
			}			


		} catch (Exception e) {
			log.debug("Exception is ==" + e.getMessage());
		}
	}


	//---------------Docker Reader--------------------
	public List<String> getOperationsBatW() {       
		String property = 
				pro.getProperty("OperationsBatW");    
		List<String> propertyList = 
				new ArrayList<>(Arrays.asList(property.split(",")));  
		return propertyList;
	}

	public List<String> getOperationsBashLnx() {       
		String property = 
				pro.getProperty("OperationsBashLnx");    
		List<String> propertyList = 
				new ArrayList<>(Arrays.asList(property.split(",")));  
		return propertyList;
	}

	public String getStatusFile() {
		return pro.getProperty("StatusFile");
	}

	public String getDockerStatusLine() {
		return pro.getProperty("DockerStatusLine");
	}

	public String getDockerStopLine() {
		return pro.getProperty("DockerStopLine");
	}

	public String getDockerURL() {
		return pro.getProperty("DockerURL");
	}

	//---------------------------------------------

	public String getGridStartBatW() {
		return pro.getProperty("GridStartBatW");
	}

	public String getGridStopBatW() {
		return pro.getProperty("GridStopBatW");
	}

	public String getGridStartBashLnx() {
		return pro.getProperty("GridStartBashLnx");
	}

	public String getGridStopBashLnx() {
		return pro.getProperty("GridStopBashLnx");
	}

	public String getGridStartStatusFile() {
		return pro.getProperty("GridStartStatusFile");
	}

	public String getGridStatusLine() {
		return pro.getProperty("GridStatusLine");
	}

	//---------------End Docker Reader--------------------

	public String getBrowser() {
		return pro.getProperty("Browser");
	}

	public String getUsername() {
		return pro.getProperty("reus");
	}

	public String getPassword() {
		return pro.getProperty("drow");
	}

	public String getQAURL() {
		return pro.getProperty("QAURL");
	}
	
	public String getYaleHomeHeader() {
		return pro.getProperty("YaleHomeHeader");
	}

	public String YaleHomeHeader() {
		return pro.getProperty("YaleHomeHeader");
	}

	public String getStartedBtn() {
		return pro.getProperty("Get Started");
	}
	
	public List<String> PageHeaders() {
		String property = 
				pro.getProperty("PageHeaders");    
		List<String> propertyList = 
				new ArrayList<>(Arrays.asList(property.split(",")));  
		return propertyList;
	}
}
