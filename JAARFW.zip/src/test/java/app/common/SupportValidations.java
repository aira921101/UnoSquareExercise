package app.common;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class SupportValidations {
	WebDriver driver;
	SeleniumActions selact;
	ExplicitWaitFunctions exwait;
	JavaScriptFunctions jsf;
	private static final Logger log = LogManager.getLogger(SupportValidations.class.getName());

	public SupportValidations(WebDriver driver) {
		this.driver = driver;
		exwait = new ExplicitWaitFunctions(driver);
		selact = new SeleniumActions(driver);
		jsf = new JavaScriptFunctions(driver);
	}

	/**
	 * 
	 * This method verifies that a WebElement is present
	 * 
	 * @param webEl
	 *
	 */
	public void verifyElementExists(WebElement webEl, int timeout) {
		Assert.assertTrue(exwait.waitForVisibilityOfElement(webEl, timeout));
		jsf.shadeElem(webEl);
		log.info("The WebElement: " + webEl + " is present");
	}


	/**
	 * 
	 * This method verifies that a WebElement has the right Header
	 * 
	 * @param actualStr
	 * @param expectedStr
	 */
	public void verifyStringContains(String actualStr, String expectedStr) {
		log.info("The Actual String is: " +actualStr +" and contains the Expected String: " + expectedStr);
		Assert.assertTrue(actualStr.toLowerCase().contains(expectedStr.toLowerCase()));
	}

	/**
	 * 
	 * This method verifies that a WebElement is equal to an expected value
	 * 
	 * @param wElement
	 * @param expectedText
	 * @param timeout
	 */
	public void verifyElementIsEqual(WebElement wElement, String expectedText, int timeout) {
		Assert.assertTrue(
				exwait.waitForVisibilityOfElement(wElement, timeout));
		jsf.shadeElem(wElement);
		String str = selact.getElementText(wElement);

		log.info("The Actual element is: " + str + " The Expected element is: " + expectedText);
		Assert.assertEquals(str, expectedText);
	}

	/**
	 * 
	 * This method verifies that a WebElement has the right Header
	 * 
	 * @param wElement
	 * @param expectedHeader
	 */
	public void verifyElementContains(WebElement wElement, String expectedHeader, int timeout) {
		Assert.assertTrue(
				exwait.waitForElementToContain(wElement,expectedHeader, timeout));
		jsf.shadeElem(wElement);
		String str = selact.getElementText(wElement);

		log.info("The Actual text is: " + str );
		Assert.assertTrue(str.contains(expectedHeader));
	}
	

}