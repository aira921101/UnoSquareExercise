package app.common;

public class Constants {
	
	public static final int EXPLICIT_WAIT_HOMEPAGE = 100;	
	public static final int CLICKABLE_SHORTWAIT = 100;
	public static final int CLICKABLE_LONGWAIT = 300;
}
