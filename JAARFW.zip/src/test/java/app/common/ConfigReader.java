package app.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * 
 * This class reads the values from the file configuration.properties
 * 
 * @return Value from configuration.properties
 */
public class ConfigReader {
	private String env;
	private final Logger log = LogManager.getLogger(ConfigReader.class.getName());
	Properties pro;

	public ConfigReader(String env) {
		this.env = env;

		try {

			if(env.equalsIgnoreCase("Prod")) {
				File src = new File("./configurationprod.properties");
				log.info("The environment is: "+ env);
				FileInputStream fis = new FileInputStream(src);

				pro = new Properties();

				pro.load(fis);
			} else if(env.equalsIgnoreCase("Test")) {
				File src = new File("./configuration.properties");
				log.info("The environment is: "+ env);
				FileInputStream fis = new FileInputStream(src);

				pro = new Properties();

				pro.load(fis);
			}			


		} catch (Exception e) {
			log.debug("Exception is ==" + e.getMessage());
		}
	}


	public String getBrowser() {
		return pro.getProperty("Browser");
	}

	public String getQAURL() {
		return pro.getProperty("QAURL");
	}
	
	public String getSearchKeyword() {
		return pro.getProperty("YaleHomeHeader");
	}
	
	public List<String> getSearchKeywords() {
		String property = 
				pro.getProperty("SearchKeywords");    
		List<String> propertyList = 
				new ArrayList<>(Arrays.asList(property.split(",")));  
		return propertyList;
	}
}
