package app.common;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Explicit wait for elements returning a boolean value
 * 
 * @param webEl
 * @param timeout
 * @return boolean
 */
public class ExplicitWaitFunctions {
	WebDriver driver;

	private static final Logger log = LogManager.getLogger(ExplicitWaitFunctions.class.getName());

	public ExplicitWaitFunctions(WebDriver driver) {
		this.driver = driver;
	}

	public ExplicitWaitFunctions() {
	}

	/**
	 * Sets the amount of time in SECONDS to wait for a page load to complete before returns false.
	 * 
	 * If the timeout is negative, page loads can be indefinite.
	 * 
	 * @param timeout
	 * @return Boolean value if the page finished loading in the defined timeout.
	 */
	public boolean waitForPageToLoad(int timeout) {
		try {
			log.info("Waiting for page to load:: " + timeout + " seconds...");
			driver.manage().timeouts().pageLoadTimeout(timeout, TimeUnit.SECONDS);
			return true;

		} catch (Exception e) {
			log.error("The page didn't finished loading... "+ e);
			return false;
		}
	}
	
	/**
	 * 
	 *  Method to wait for the page to return "readyState" using JavaScript
	 * 
	 * @param webEl
	 * @param attribute
	 * @param value
	 * @param timeout
	 * @return 
	 */
	public boolean javaScriptWaitWholePageToLoad(int timeout) {
		try {
			log.info("Waiting for max:: " + timeout + " seconds for the Page to be visible");
			WebDriverWait wait = new WebDriverWait(driver, timeout);
			wait.until((ExpectedCondition<Boolean>) wd ->
			   ((JavascriptExecutor) wd).executeScript("return document.readyState").equals("complete"));			
			
			log.info("The Page was loaded");
			return true;
			
		} catch (Exception e) {
			log.debug("The page didn't load " + e);
			return false;
		}

	}

	/**
	 * Method to wait for the WebElement to contain and specific string
	 * 
	 * @param webEl
	 * @param timeout
	 * @return boolean
	 */
	public boolean waitForElementToContain(WebElement webEl,String expString, int timeout) {
		if (expString != null) {
			try {
				log.info("Waiting for max:: " + timeout + " seconds for string " + expString
						+ " to be present in the Element");
				WebDriverWait wait = new WebDriverWait(driver, timeout);
				wait.until(ExpectedConditions.textToBePresentInElement(webEl, expString));
				log.info("The element contains: " + expString);
				return true;

			} catch (Exception e) {
				log.debug("The Element doesn't contains: " + expString + e);
				return false;
			}
		} else
			log.error("The String is null");
		return false;
	}
	
	/**
	 * 
	 * Method to wait for the Title to contain and specific string
	 * 
	 * @param expString
	 * @param timeout
	 * @return
	 */
	public boolean waitForTitleToContains(String expString, int timeout) {
		if (expString != null) {
			try {
				log.info("Waiting for max:: " + timeout + " seconds for string " + expString
						+ " to be present in the Title");
				WebDriverWait wait = new WebDriverWait(driver, timeout);
				wait.until(ExpectedConditions.titleContains(expString));
				log.info("The " + expString + " is present in the Title");
				return true;

			} catch (Exception e) {
				log.debug("The Title doesn't contains " + expString + e);
				return false;
			}
		} else
			log.error("The String is null");
		return false;
	}

	/**
	 * Method to wait for the visibility of a WebElement
	 * 
	 * @param webEl - The WebElement 
	 * @param timeout - Time in SECONDS
	 * @return Boolean value - Returns false if the element is not visible after the timeout.
	 */
	public boolean waitForVisibilityOfElement(WebElement webEl, int timeout) {
		if (webEl != null) {

			try {
				log.info("Waiting for max:: " + timeout + " seconds for element " + webEl.toString() + " to be visible");

				WebDriverWait wait = new WebDriverWait(driver, timeout);
				wait.until(ExpectedConditions.visibilityOf(webEl));
				log.info("Element " + webEl.toString() + " is present");
				return true;

			} catch (Exception e) {
				log.debug("Element " + webEl.toString() + " is not present " + e);
				return false;
			}
		} else
			log.error("Element is null");
		return false;
	}

	/**
	 * Method to wait for the visibility of an Element
	 * 
	 * @param xpath - The element's xPath 
	 * @param timeout - Time in SECONDS 
	 * @return Boolean value - Returns false if the element is not visible after the timeout.
	 */
	public boolean waitForVisibilityOfElement(String xpath, int timeout) {
		WebElement webEl = driver.findElement(By.xpath(xpath));

		if (webEl != null) {

			try {
				log.info("Waiting for max:: " + timeout + " seconds for element " + webEl.toString() + " to be visible");

				WebDriverWait wait = new WebDriverWait(driver, timeout);
				wait.until(ExpectedConditions.visibilityOf(webEl));
				log.info("Element " + webEl.toString() + " is present");
				return true;

			} catch (Exception e) {
				log.debug("Element " + webEl.toString() + " is not present " + e);
				return false;
			}
		} else
			log.error("Element is null");
		return false;
	}
	/**
	 * Method to wait for an Element to be Clickable
	 * 
	 * @param xpath - The WebElement 
	 * @param timeout - Time in SECONDS 
	 * @return Boolean value - Returns false if the element is not yet clickable nor enabled.
	 */
	public boolean waitForElementToBeClickable(WebElement webEl, int timeout) {
		if (webEl != null) {

			try {
				log.info("Waiting for max:: " + timeout + " seconds for element " + webEl.toString()
				+ " to be clickable");

				WebDriverWait wait = new WebDriverWait(driver, timeout);

				wait.until(ExpectedConditions.elementToBeClickable(webEl));
				log.info("Element " + webEl.toString() + " is clickable");
				return true;

			} catch (Exception e) {
				log.debug("Element " + webEl.toString() + " is not clickable " + e);
				return false;
			}
		} else
			log.error("Element is null");
		return false;

	}

	/**
	 * Method to wait for an Element to be Clickable
	 * 
	 * @param xpath - The element's xPath 
	 * @param timeout - Time in SECONDS 
	 * @return Boolean value - Returns false if the element is not yet clickable not enabled.
	 */
	public boolean waitForElementToBeClickable(String xpath, int timeout) {
		WebElement webEl = driver.findElement(By.xpath(xpath));

		if (webEl != null) {

			try {
				log.info("Waiting for max:: " + timeout + " seconds for element " + webEl.toString()
				+ " to be clickable");

				WebDriverWait wait = new WebDriverWait(driver, timeout);

				wait.until(ExpectedConditions.elementToBeClickable(webEl));
				log.info("Element " + webEl.toString() + " is clickable");
				return true;

			} catch (Exception e) {
				log.debug("Element " + webEl.toString() + " is not clickable " + e);
				return false;
			}
		} else
			log.error("Element is null");
		return false;

	}

}


