package app.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class WebSiteFunctions {

	WebDriver driver;
	ExplicitWaitFunctions ewaits;
	private final Logger log = LogManager.getLogger(ExplicitWaitFunctions.class.getName());

	public WebSiteFunctions(WebDriver driver) {
		this.driver = driver;
		ewaits = new ExplicitWaitFunctions(driver);
	}


	public  void goBackHomePage() {
		driver.navigate().back();
	}
	
	public boolean isElementClickable(WebElement element) {
		if (element.isDisplayed() && element.isEnabled()) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean isElementPresentById(String id) { 
		boolean isDisplayed = driver.findElement(By.id(id)).isDisplayed();
		return isDisplayed;
	}
	
	public boolean isElementPresent(WebElement xpathSource) { //MV533 Implementation
		//WebElement we = xpathSource));
		//Assert.assertTrue(ewaits.fluentWaitForVisibilityOfElement(xpathSource, 10, 4));
		boolean isDisplayed = xpathSource.isDisplayed();
		return isDisplayed;
	}
}
